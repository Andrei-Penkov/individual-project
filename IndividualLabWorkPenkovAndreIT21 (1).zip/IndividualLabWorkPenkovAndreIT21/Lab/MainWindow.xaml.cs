﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.Xml;
using Microsoft.Win32;
using System.Threading;

using ClassLibGun;
using ClassLibLoad;

namespace Lab
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {

        private Collect<Ammo> ammos;
        private Collect<Cannon> cannons;

        private Ammo CurrentAmmo;
        private Cannon CurrentCannon;

        public MainWindow()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
            InitializeComponent();

            ammos = new Collect<Ammo>();
            cannons = new Collect<Cannon>();

            try
            {
                LoadXML provider = new LoadXML();
                string fname = provider.LoadX();


                XDocument doc = XDocument.Load(fname);


                doc.Descendants("Cannon").Select(x => new
                {
                    name = x.Attribute("name").Value,
                    cal = x.Element("caliber").Value
                }).ToList().ForEach(x =>
                {
                    cannons.Add(new Cannon(x.name, int.Parse(x.cal)));
                });

                doc.Descendants("Ammo").Select(x => new
                {
                    name = x.Attribute("name").Value,
                    cal = x.Element("caliber").Value,
                    vel = x.Element("vel").Value
                }).ToList().ForEach(x =>
                {
                    ammos.Add(new Ammo(x.name, int.Parse(x.cal), int.Parse(x.vel)));
                });

            }
            catch (Exception ex) 
            {
                MessageBox.Show("Этот файл не подходит для данного приложения");
            }


            Gun.ItemsSource = from cannon in cannons
                              select cannon.ToString();
            Am.ItemsSource = from ammo in ammos
                             select ammo.ToString();
        }

        private void Am_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                CurrentAmmo = ammos[Am.SelectedIndex];
                A.Text = CurrentAmmo.Vel.ToString();
                A_Cop.Text = CurrentAmmo.Сaliber.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Выберите снаряд");
            }
        }

        private void Gun_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                CurrentCannon = cannons[Gun.SelectedIndex];
                G.Text = CurrentCannon.Name;
                G_Cop.Text = CurrentCannon.Сaliber.ToString();
            }
            catch (Exception ex1)
            {
                MessageBox.Show("Выберите орудие");
            }
        }

        private void Res_Click(object sender, System.EventArgs e)
        {
            if (CurrentCannon!=null && CurrentAmmo!=null)
            {
                if (double.TryParse(Distance.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double number))
                {
                    if (double.Parse(Distance.Text) < 0)
                        Rez.Text = "Отрицательное расстояние";
                    if (CurrentCannon.Сaliber != CurrentAmmo.Сaliber)
                        Rez.Text = "Не одинаковый калибр";
                    else
                        Rez.Text = (Math.Asin((CurrentCannon + CurrentAmmo) * double.Parse(Distance.Text)) * (180 / 3.14) / 2).ToString();
                }
                else
                {
                    Rez.Text = "Введено не число";
                }
            } else
            {
                Rez.Text = "Выберите элементы";
            }
        }
        
    }
}
