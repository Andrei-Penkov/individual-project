﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibLoad
{
    public class LoadXML : ILoad
    {
        public string LoadX()
        {
            string fname = string.Empty;
            OpenFileDialog openFileDlg = new OpenFileDialog();
            openFileDlg.InitialDirectory = System.IO.Directory.GetParent(@"..\..\..\").FullName; ;
            openFileDlg.DefaultExt = ".xml";
            openFileDlg.Filter = "Text Documents (.xml)|*.xml";
            bool? result = openFileDlg.ShowDialog();
            if (result == true)
            {
                fname = openFileDlg.FileName;
            }
            return fname;
        }
    }
}
