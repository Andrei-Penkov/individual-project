﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibGun
{
    public class Ammo : Cannon
    {
        public Ammo(string name, int сaliber, int vel) : base(name, сaliber)
        {
            Vel = vel;
        }

        public Ammo(): base() 
        {
            Vel = 0;
        }

        
        public int Vel { get; set; }


        public static double operator +(Cannon a1, Ammo a2)
        {
            return (10.0 / (a2.Vel * a2.Vel));
        }

        public override string ToString()
        {
            return String.Format("{0}", Name);
        }
    }
}
