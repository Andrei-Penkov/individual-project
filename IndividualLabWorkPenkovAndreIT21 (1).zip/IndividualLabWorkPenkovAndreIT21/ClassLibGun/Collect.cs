﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClassLibGun
{
    public class Collect<Ga> : IList<Ga>
    {


        private readonly IList<Ga> data = new List<Ga>();

        public Ga this[int index]
        {
            get
            {
                if (index < 0 || index >= Count)
                    throw new IndexOutOfRangeException();
                return data[index];
            }

            set
            {
                if (index < 0 || index >= Count)
                    throw new IndexOutOfRangeException();
                data[index] = value;
            }
        }



        public bool IsReadOnly => false;


        public int Count
        {
            get
            {
                return data.Count;
            }
        }

        public int Length {
            get
            {
                return data.Count;
            }
        }

        public void Add(Ga item)
        {
            data.Add(item);
        }


        public void Clear()
        {
            data.Clear();
        }

        public bool Contains(Ga item)
        {
            return data.Contains(item);
        }

        public void CopyTo(Ga[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public IEnumerator<Ga> GetEnumerator()
        {
            return data.GetEnumerator();
        }

        public int IndexOf(Ga item)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index, Ga item)
        {
            throw new NotImplementedException();
        }

        public bool Remove(Ga item)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }
        
        IEnumerator IEnumerable.GetEnumerator()
        {
            return data.GetEnumerator();
        }

    }
}
